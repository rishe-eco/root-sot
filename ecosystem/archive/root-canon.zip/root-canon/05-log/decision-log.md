# Root · ریشه — Decision Log
*Living, append-only. The path we've taken: what we decided, what we broke, what we set aside. Newest at top of each section. Don't rewrite history — append.*

**Started 2026-07-14 · Owner: _root**

---

## How the product reshaped itself

- **Thesis reached its telos: "in search of beauty."** The frame moved from *get stuff done and maintain* → *know yourself and grow* → **the person authors their own life, in search of beauty; Root never authors it for them.** Self-authorship is the mechanism, beauty the direction; "know yourself and grow" demoted to orienting descriptor. Root reframed as a *self-authorship company*, not a self-improvement app (Brand §1, §3).
- **The fifth pillar was found, not added.** Working from the four (Reflect, Organize, Learn, Maintain), the gap read first as *forward* (vision) then resolved as *outward*: the load-bearing axiom (self-view is flawed until mirrored externally) makes an outward pillar structurally necessary. It also completes the SDT triad (relatedness was the uncovered need). Others is the outward mirror that makes self-knowledge possible — not an afterthought.
- **Service reframed: discipline is the container for compassion, not its enemy.** Rejected the binary of "authentic service can't be tracked" vs. "tracked service is inauthentic." Service acts get full Organize rigor; the discipline proves the compassion is commitment, not sentiment.
- **Immediate-action-only locked for Reflect and Maintain.** If either surfaces something actionable, it's now-or-handoff (Learn/Organize/Others). No intervals, no deferral — deferral would mean the app condoning another day in a depleted/unmet state, and it's the hard fence against overjustification.
- **Reflect↔Organize found to be tightly coupled** — first on service (motive check in, execution out), then on failure (structural read in Organize, emotional/meaning read in Reflect).
- **Learn's first module: spiral, not ladder.** The bare loop never retires; distinctions and storytelling layer on top inside one practice. Coupled feelings+needs, mindset before vocabulary, A before B. Storytelling tier *is* the Reflect on-ramp.
- **Persian-first became non-negotiable on evidence, not preference** — affect labeling in a non-native language doesn't down-regulate.
- **Organize: mindset-first, and four outcomes separated** (recognize / understand loopholes / track / set new). Outcome 2 (loopholes) is the leverage point; understanding lives in Organize, fixing in Learn.
- **The engine: 14 steps folded into 5 phases around the Opportunity Solution Tree.** The tree became the single shared artifact; the gate definition doubles as the async coordination protocol.
- **Canonical/living split adopted; Affine chosen** for the living layer (trees, kanban, portfolio); markdown canon repo for the stable layer.

## Naming

- **Persian master name revised بن → ریشه.** بن read as a coupon/discount word; ریشه ("root") carries the intended meaning cleanly. English stays "Root."
- **Others** kept as a *working* name; candidates Contribute / Serve / Relate / خدمت recorded (`others.md` §2). Not resolved.

## What we broke / corrected

- Corrected an initial collapse of Organize's outcomes into one sentence — they are four distinct discovery problems.
- Corrected the mis-assignment of the "measuring changes the measured" risk to Maintain; it concentrates in **Reflect** (articulation). The B-10 / device-in-the-drawer concern is **Organize/Today's** (action deferral), not Maintain's.
- Separated two risks conflated as one under "streaks": the avoidable **streak-cliff** (solved by not building streaks) and the ambient **motivation-fade** abandonment (the genuinely hard one, deferred).
- Reframed Reflect's pattern-recognition from a core feature to a **gated** one pending professional psychological review.
- Distinguished the *team's* working language (English) from the *product's* feelings/needs language (Persian-first) — different constraints.

## Set aside (deferred, on purpose)

- **Others: relationship management subcomponent** — TBD, later; the "close relationships handled via Reflect/Maintain" claim is contested and left open.
- **Reflect: cross-entry pattern recognition** — pending professional sign-off.
- **Learn: pathway recommendation logic; integration-vs-separation of module delivery** — discovery questions.
- **Maintain: the battery metaphor's concrete visual form.**
- **Journey: the integration indicator** (when to merge pillars) and whether any pillar becomes a standalone product.
- **Business model final shape** and how far local-first is achievable given the agent.
- **Tagline salon test** (both languages); descriptor final wording; Journey's own line.

## Constraints locked

Tech: Vite + React Router (frontend), Express + GraphQL + Prisma/SQLite (backend). Bilingual: Root/ریشه, Journey/ماجرا. LLM: Mistral primary (EU), Qwen secondary, tool-layer capability limits. Team: three, remote, async-first. Engine: one pillar in Phase-3 test at a time; others parallel in Phases 1–2. All five convictions and the anti-engagement ethos: non-negotiable.

---

## Changelog

- **2026-07-14** — Log started. Captured the evolution to date, corrections, deferrals, and locked constraints from the design conversations. *(Reconstructed from memory of prior sessions; treat pre-dated entries as best-effort, not verbatim record.)*
