# Root · ریشه — Pillar: Learn
*Source of truth. Short on purpose. Concept + first module. Update the changelog; don't fork.*

**Version 0.1 (draft) · 2026-07-14 · Owner: _root**

---

## 1. Purpose

Learn is where a person builds capacity on purpose. The general shape: choose a skill, evaluate where you are, set an endpoint and an intensity for a period, follow a pathway, track progress, and evaluate at points along the way. Learn is fed by every other pillar (a gap surfaces in Reflect, Maintain, Organize, or Others) and returns capacity to Organize, where the new ability makes new action possible.

## 2. First module — Emotion & Need Language Building

The founding module, and the on-ramp to Reflect. Design principles, all grounded (see `04-research/`):

- **One coupled module, not two tracks.** Feelings and needs are two ends of one mechanism — a feeling is the signal, the need is what it signals about. Teaching feelings alone trains reading a gauge without knowing what it measures.
- **Mindset before vocabulary; A before B.** First the frame (emotions are workable signals about needs, not verdicts). Then competence A (vocabulary), then competence B (distinctions: feeling-vs-thought, need-vs-strategy) — B is a refinement layer on top of A, never the opening move.
- **A spiral, not a ladder.** The bare loop never retires. Distinctions and storytelling grow *on top of it, inside the same practice.* "How long do I repeat this" dissolves: repetition *is* the training, not a toll paid to advance.

## 3. The three tiers

1. **Day one — the frame, felt not told (~6 min, once).** Recall a moment you felt "off"; find it in the body; try a few words on; notice that naming gave you a handle though nothing else changed. The malleability belief is *experienced*, not asserted.
2. **The bare loop (~3 min, daily-ish, the permanent spine).** Breath → *where/what texture in the body?* (interoception on-ramp, keeps attention off the "why am I like this" spiral) → reach for a word, try it on (small palette, weighted to pleasant/met-need early) → *if this points at something you care about, what?* (need offered, never forced) → *anything small this makes you want to do or ask for?* (optional — the seam into Reflect).
3. **Distinctions, surfaced in-context (~week 2, many distributed touches).** When the person types a faux-feeling ("ignored"), the app gently catches it: that's more a read on what someone did — underneath, the feeling (hurt? lonely?) and the need (to matter? to be included?). Taught by contrast on the person's own live material (variation theory), never as a standalone drill.
4. **Storytelling (~week 3–4, 10–15 min, weekly-ish).** Take a whole moment apart: observation → first/loudest feeling → what's underneath → the needs in play (often plural, sometimes in conflict) → what it clarifies. This *is* a guided journal entry — so it's not "graduating to Reflect," it's walking through a door you're already standing in.

All numeric thresholds ("7–10 loops," "week 3") are **dials for the evaluation-and-settings layer** to tune per user. For the prototype, hardcode them.

## 4. The bilingual constraint (non-negotiable)

Affect labeling in a **non-native** language does not down-regulate emotion — the regulation effect requires the dominant emotional language. Therefore the feelings/needs work is **Persian-first for Persian users**; the English layer is translation/bridge, never the primary medium. This is a design constraint, not a preference, and it is one of the deepest reasons Root is Persian-first (Brand §2).

## 5. Guardrails

- **Naming is not analyzing.** The loop must keep moving (notice → name → need → small thing); parking in "why do I always feel this" is rumination, the opposite of the regulating move.
- **Don't oversell vocabulary size.** The payoff is *granularity built in context* + a malleability mindset, not word-count (the two are distinct constructs).

## 6. Prototype scope (for the team to feel the pillar)

Three screens convey the whole thing: the Day-1 frame moment, one bare loop, one loop where a distinction surfaces. Storytelling can be a described mockup for v0. This transmits the feel — short, body-first, in-your-own-words, always moving toward a need, teaching by gentle catch rather than quiz.

## 7. The natural sequel

**Reality-check-and-biases** is the literal next module: it operates on the exact object this module teaches people to notice — "interpretations about what others did" (the faux-feelings). Once you can see an interpretation *as* an interpretation, examining it is the next discipline. It also feeds back into Reflect's reality-check move.

## 8. Decision test

Does the module build *real capacity the person can carry into their own life*, in their own emotional language, by doing — or does it teach a taxonomy to recite? The second is off-pillar.

## 9. Open questions

- Pathway recommendation logic (how a learning path is proposed) — undetermined.
- Integration vs. separation of module delivery (learned-through-Reflect-interaction vs. structured module) — a discovery question.
- Module set beyond the first two; per-module evaluation design.

---

## Changelog

- **0.1 · 2026-07-14** — Initial draft, from the emotion/need module design. Spiral (not ladder) model, three tiers, Persian-first affect-labeling constraint, guardrails, prototype scope, reality-check sequel.
