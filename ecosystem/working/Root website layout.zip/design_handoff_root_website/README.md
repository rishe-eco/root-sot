# Handoff: Root Website — Public Front + Portal (Phase 1)

## Overview
Root (ریشه) is a Persian-first, bilingual (FA/EN) self-authorship platform. This package covers four screens:

1. **Landing** — public marketing home.
2. **About Us** — a short brand introduction + a "clients / open the portal" CTA.
3. **Portal · Contracts** — authenticated customer dashboard: a list of the customer's contracts.
4. **Portal · Contract Detail** — the interactive contract review flow (design approval → contract approval → e-signature), the urgent Phase-1 piece.

All four are **bilingual with full RTL**. Persian is the default and primary language; English is a toggle. Layout uses CSS logical properties (`inline-start`/`block-end`, etc.) so mirroring is automatic when `dir="rtl"`.

## About the Design Files
The `.dc.html` files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior. They are **not production code to copy directly**. Each is a "Design Component" that runs on a small custom runtime (`support.js`) using a simple template + logic-class model; that runtime is an authoring convenience, **not** something to ship.

Your task is to **recreate these designs in the target codebase's environment**, using its established patterns and libraries. The intended stack (from the project brief) is **Vite + React**, a **GraphQL (Apollo) + Prisma + Postgres** backend, bilingual Persian-first with RTL, reusing the shared token system. If no environment exists yet, build them in React with the token/kit CSS included here as the styling foundation.

The two CSS files are the real, portable design system and **should be carried over**:
- **`tokens.css`** — the design tokens (CSS custom properties): color ramps, semantic colors, type scale, spacing, radius, shadows, motion, and Persian line-height overrides.
- **`kit.css`** — component classes built on those tokens (typography, buttons, badges, cards, form fields, nav, footer, lock glyph).

Each screen's HTML `<style>` block contains only **page-specific layout** on top of `kit.css`. Port the token + kit layer once, then rebuild each screen as components.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, radii, and interactions are all specified via `tokens.css`/`kit.css` and should be reproduced faithfully. Recreate the UI pixel-accurately using the codebase's libraries; do not invent new colors — every value comes from a token.

---

## Screens / Views

### 1. Landing — `Root Landing (design system).dc.html`
- **Purpose:** Public home. State the thesis, offer a single primary action.
- **Layout:** Full-height column. Sticky-feeling top `nav` (brand start, locked nav items center, Portal label + EN/فا switch end). Hero is a flex row: `hero-main` 60% (eyebrow, big headline with gold "beauty" span, lead paragraph, primary button), a 20% spacer, and a 20% `hero-side` "Root Cast" coming-soon panel. Below: a "Where Root grows" section with three top-ruled cards (Coaching, Communication & Peacebuilding, Education). Footer mirrors the brand + refusal line + copyright. Hero collapses to a single column below 600px.
- **Key components:** `.nav`, `.nav-link` / `.nav-link-locked` (locked items show the label **blurred** with a padlock glyph centered on top — see Interactions), `.hero-title` (`--text-display` EN / `--text-h2` FA), `.btn.btn-primary.btn-lg`, `.card.card-panel` (side panel), `.card.card-topruled` (growth cards), `.footer`.

### 2. About Us — `Root About.dc.html`
- **Purpose:** Short brand intro + a quiet path to the portal for existing clients.
- **Layout:** Same nav + footer as Landing. Main is a centered column (`max-inline-size: 1040px`) with two blocks:
  - **Gist block:** eyebrow, thesis headline (`--text-h1` EN / `--text-h2` FA) with a gold `.beauty` span, one lead paragraph.
  - **Clients CTA card:** dark `.card.card-inverse` (indigo ground), rounded 24px, generous padding. Contains a warm-beige eyebrow (`#CBB9A6`), a large white heading (`--text-display` EN / `--text-h1` FA), a light body (`--indigo-200`), and a clay primary button "Open the portal" linking to the portal. Copy (EN): eyebrow "Clients", heading "Already working with us?", body "Track your contract, approve designs, and see what you owe — all in one quiet place.", button "Open the portal".

### 3. Portal · Contracts — `Root Portal - Contracts.dc.html`
- **Purpose:** Logged-in customer sees all their contracts and drills into one.
- **Layout:** Two-pane app shell — a fixed **250px sidebar** (`.side`, `--color-footer` ground, `border-inline-end`) + a flexible **work column** (`.work`). Sidebar: brand link, "Workspace" caption, nav links **Contracts** (active), **Services / Billing / Support** (shown disabled with a gold "Soon" tag — later phases). Work column: `.topbar` (page title + EN/فا switch + user avatar chip) then `.content` (max 1120px): page title + lede, a row of **status filter chips** (with counts), and a bordered `.table-wrap` table. Sidebar collapses to a 76px icon rail below 860px; the Amount column hides.
- **Table columns:** Contract (name + client sub-line), Status (badge), Amount (Toman), Last update, and a "View ›" link. Whole row is clickable → Contract Detail.
- **Status badges** (`.st-badge` + modifier, pill with a leading dot):
  - Draft `.st-draft` — neutral-200 bg / neutral-700 text
  - Waiting on Customer `.st-woc` — gold-100 / gold-600
  - Waiting on Root `.st-wor` — cyan-100 / cyan-700
  - In Progress `.st-inprogress` — clay-50 / clay-600
  - Final Review `.st-finalreview` — indigo-100 / indigo-500
  - Done `.st-done` — solid indigo-500 / neutral-100
  - Discarded `.st-discarded` — neutral-300 / neutral-600
- **Filter chips:** `.chip` (outline) / `.chip-active` (indigo fill, inverse text). "All" + one per status; each shows a count. Filtering is client-side over the row list.

### 4. Portal · Contract Detail — `Root Portal - Contract Detail.dc.html`
- **Purpose:** The interactive review page. Turns each static contract section into an action, with a strict approval gate.
- **Layout:** Same app shell. Topbar shows a breadcrumb (Contracts / <title>). Main is a **two-column grid**: `detail-main` (min 0, 1fr) + a **320px sticky `rail`**. Collapses to one column below 980px. Five numbered `.sec` cards down the main column; the rail holds a Status card and a History (change-log) card.
- **Sections:**
  1. **Design selection & approval.** Three selectable concept cards (`.concept`, a faux browser-chrome preview with the concept id `1a/1b/1c`). Clicking one marks it `.concept-chosen` (clay border + soft ring) and dims the others (`.concept-dim`). Once chosen, a **page-designs** list appears (Landing, About, Contracts, Portal login) — each row has an Approve button that toggles to "✓ Approved" and tints the row (`.pagerow-done`, cyan). A progress line reads "N of 4 pages approved"; when the concept is chosen **and** all pages approved, it shows a green-cyan "Design approved & complete" pill.
  2. **Contract body.** A scrollable `.articles` panel: 14 numbered articles + "Appendix 1 — Feature list", each expandable (accordion, one open at a time; first three have real body text, the rest a placeholder line). An **Approve contract** button is **disabled until "design approved & complete"**; while locked it shows a padlock hint. Approving flips it to "✓ Contract approved".
  3. **Scope checklist (Appendix 1).** Six tappable items with custom checkboxes (`.check` / `.check-on`, cyan when on). Always editable, never gated.
  4. **E-signature.** **Locked until the contract is approved** (padlock hint shown). When unlocked: a full-name text field + "Sign & finalize" button (disabled until ≥2 chars). After signing, a cyan confirmation panel shows the typed name in a script style + timestamp.
  5. **Comments & feedback.** An always-open thread (seeded with one Root comment) + a textarea and "Post comment" button (disabled while empty). New comments append with author avatar, name, and "Just now · HH:MM".
- **Rail — Status card:** a status badge (Waiting on Customer by default; becomes In Progress once signed) and a 3-step **gate stepper**: (1) Design approved & complete, (2) Contract approved, (3) Signed. Each step is `done` (cyan ✓), `active` (clay ring ○), or `locked` (muted ·).
- **Rail — History card:** the change log, newest first, each entry = actor (Root/You) + action + timestamp. Seeded with "Root created the contract / published it to you"; every user action (choose concept, approve/un-approve page, design complete, approve contract, sign, comment, scope toggle) appends an entry.

---

## Interactions & Behavior

- **Language toggle (all screens):** EN/فا buttons flip `lang` + `dir` on the root element and swap all copy. FA is default. Fonts: **Vazirmatn** (Persian), **Inter** (Latin) — see `--font-persian` / `--font-latin`. All spacing/borders use logical properties so RTL mirrors automatically.
- **Locked nav items (Landing/About):** the text label is rendered **blurred and unreadable** (`filter: blur(4.5px); opacity: 0.5`) with a small padlock glyph absolutely centered on top. This is intentional brand language ("present, named, honestly not ready"), not a placeholder. A visually-hidden `.sr-only` "Coming later" is present for screen readers.
- **Contract Detail gate (the core rule):**
  `design approved & complete → unlock "Approve contract" → unlock "E-sign"`.
  - Design complete = a concept is chosen AND all page designs approved.
  - Choosing a different concept resets page approvals.
  - Commenting and the scope checklist are **never gated**.
- **Buttons:** `.btn` transitions on hover; primary = clay fill, secondary = outline, ghost = muted. Disabled uses `opacity: 0.45; cursor: not-allowed`.
- **Table rows / cards:** hover raises background to `--color-panel`; concept/page selection has `--dur-fast` transitions on border/box-shadow/opacity.
- **Motion:** durations/easing come from `--dur-fast` / `--dur-base` / `--ease` in `tokens.css`. Keep it subtle — restraint is a brand principle.
- **Responsive:** Landing hero stacks < 600px; portal sidebar becomes an icon rail < 860px; contract-detail grid becomes one column < 980px.

## State Management
State currently lives in each prototype's logic class; in React model it as component/route state (and, in production, server data via GraphQL):

- **Global (per session):** `lang` ('fa' | 'en').
- **Contracts list:** `filter` (status key | 'all'); the contract collection (server-fetched in prod).
- **Contract Detail:**
  - `chosenConcept`: null | '1a' | '1b' | '1c'
  - `approvedPages`: set/map of pageId → true (reset when concept changes)
  - `openArticle`: index of the expanded article (accordion)
  - `scope`: map of scopeItemId → true
  - `contractApproved`: boolean (settable only when design complete)
  - `signed`: boolean; `signName`: string (sign allowed only when `contractApproved` and name ≥ 2 chars)
  - `comments`: array of { author, text, timestamp }
  - `log`: array of { actor, action, arg?, timestamp } — newest first
  - **Derived:** `designComplete = chosenConcept && all pages approved`; status = signed ? "In Progress" : "Waiting on Customer".
- **Change log:** every meaningful action (comment, design approval, scope toggle, contract approval, signature) is logged with actor + timestamp. Per the brief this history feeds a later admin review-flagging queue, so capture it from the start.

## Design Tokens
All values are defined in **`tokens.css`** — use it as the source of truth. Key values:

**Color ramps (raw):**
- Neutral (cool, indigo-tinted "drafting paper"): 50 `#F5F7F8`, 100 `#EDEFF0` (page bg), 200 `#E1E5E9`, 300 `#DCE2E7`, 400 `#C7CDD3`, 500 `#A3ADB8`, 600 `#7A8798`, 700 `#5A6A82`, 800 `#3A4759`, 900 `#232D3B`.
- Indigo (the ink): 50 `#EAEEF4` … 200 `#A8B7CD`, 300 `#7B8FAF`, 400 `#4C6689`, 500 `#1E3557` (text + dark grounds), 600 `#1A2E4B` … 900 `#0C1521`.
- Clay (the action color): 50 `#FBEDEB`, 100 `#F5D8D3`, 200 `#E7A79D`, 300 `#D4776A`, 400 `#C24B3A` (non-text only), 500 `#A83E2F` (accent when it carries a label), 600 `#8B3225`.
- Cyan (the drafting line): 50 `#EDF4F6`, 100 `#D7E7EC`, 200 `#B0CFD8`, 300 `#88B5C2`, 400 `#5E93A6` (non-text), 500 `#4E7D8E`, 600 `#3F6675` (lowest safe body rung), 700 `#33535F`.
- Gold (beauty / "coming later"): 100 `#F2E7C9`, 200 `#E5D09B`, 300 `#D4B366`, 400 `#C79A3E` (decorative), 500 `#A9851F` (large text/icons), 600 `#8A6C18` (body rung).

**Semantic:** bg = neutral-100; panel = neutral-300; footer = neutral-200; raised = neutral-50; inverse = indigo-500. text = indigo-500; text-muted = neutral-700; text-subtle = neutral-600; text-inverse = neutral-100; beauty = gold-500. border = neutral-400; border-strong = neutral-500; rule (cyan-400); rule-strong (clay-400). accent = clay-500; accent-hover = clay-600; accent-soft = clay-50; secondary = cyan-600; locked = gold-500; error = clay-600; focus = cyan-400.

**Type scale:** caption 0.75rem, small 0.875rem, body 1rem, body-lg 1.125rem, h3 1.5rem, h2 2rem, h1 3rem, display 4rem. Persian gets larger line-heights (overrides in `tokens.css`). Fonts: Vazirmatn (fa), Inter (en).

**Spacing:** `--space-1..32` = 0.25 / 0.5 / 0.75 / 1 / 1.5 / 2 / 3 / 4 / 6 / 8 rem (note: the scale is 1,2,3,4,6,8,12,16,24,32 — **there is no `--space-5`**; the portal pages use `1.25rem` literals where a mid-step was needed).

**Radius:** sm 10px, md 16px, full 999px (the inverse CTA card uses 24px). **Shadows:** sm/md/lg, cool-tinted and soft (see tokens).

## Assets
No raster images or icon fonts. All iconography is CSS/markup: the brand dot, the padlock glyph (two divs — shackle + body), status/gate dots, concept-preview browser chrome, and check marks (Unicode ✓). Concept previews and page thumbnails are placeholder blocks — in production, swap in real uploaded design images (the brief's admin uploads per-page designs). Fonts load from Google Fonts (Vazirmatn, Inter).

## Files
Design references in this bundle:
- `Root Landing (design system).dc.html`
- `Root About.dc.html`
- `Root Portal - Contracts.dc.html`
- `Root Portal - Contract Detail.dc.html`

Portable design system (carry these over):
- `tokens.css` — design tokens
- `kit.css` — component classes

Runtime (authoring only — **do not ship**):
- `support.js` — the prototype runtime, included so the `.dc.html` files open and run in a browser for reference.

To preview a file, open it directly in a browser (it loads `tokens.css`, `kit.css`, and `support.js` from the same folder).
